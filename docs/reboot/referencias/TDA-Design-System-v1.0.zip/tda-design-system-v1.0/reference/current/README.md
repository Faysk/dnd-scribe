# Referência da implementação atual

Estes arquivos são **snapshots normalizados para consulta** dos primitives e tokens observados na `main` de `Faysk/dnd-scribe` no commit `68e974c0eb240e1658772f8ae64da36530f9452e`.

Eles preservam a semântica, nomes de tokens, variantes e regras relevantes ao Design System, mas este diretório não deve ser usado como substituto de um checkout do repositório para comparação byte a byte.

A fonte operacional continua sendo o próprio repositório:

- `apps/web/app/globals.css`
- `apps/web/components/ui/action.tsx`
- `apps/web/components/ui/surface.tsx`
- `apps/web/components/ui/typography.tsx`
- `apps/web/components/ui/status.tsx`
- `docs/08_design_system_visual.md`
