# Design system visual — TDA

Este documento define o padrão visual que a interface pública do TDA deve seguir. O objetivo é impedir que cada tela invente uma paleta, um botão ou uma hierarquia diferente.

## Princípios

1. **Visitante vê história; editor vê estado editorial.** A interface pública prioriza título, arco, data, resumo e arte. Indicadores como `publicado`, `completo`, `ilustrado`, `em preparação` e métricas de cobertura não devem aparecer para o visitante, salvo quando alterarem de fato a ação disponível.
2. **Cores têm função semântica.** Componentes não devem escolher hexadecimais diretamente. Devem usar tokens do design system.
3. **Claro e escuro são a mesma identidade.** O tema muda luminância e contraste, não a hierarquia da marca.
4. **Acento é raro.** O dourado serve para marca, navegação ativa, arco, foco e ação primária. Não deve competir com título, resumo ou arte.
5. **Legibilidade vence decoração.** Texto normal deve atingir contraste WCAG AA de pelo menos 4.5:1; texto grande pode usar 3:1; limites e estados visuais de componentes interativos devem manter pelo menos 3:1 quando necessários para identificação.

A implementação oficial fica em `apps/web/app/globals.css`.
