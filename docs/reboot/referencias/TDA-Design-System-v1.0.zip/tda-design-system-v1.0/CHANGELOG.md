# Changelog

## 1.0.0 — 2026-09-06

- consolida o Design System visual já adotado no `apps/web`;
- documenta todos os tokens light/dark atuais;
- registra tipografia e componentes compartilhados;
- adiciona relatório de contraste;
- formaliza regras para ações, surfaces, cards, status, forms, navegação e movimento;
- separa claramente o que é **canônico** do que é **extensão recomendada**;
- inclui catálogo visual offline e templates de revisão.
