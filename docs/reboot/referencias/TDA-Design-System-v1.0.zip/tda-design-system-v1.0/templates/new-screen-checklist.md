# Nova tela — checklist

- [ ] define objetivo e ação principal
- [ ] escolhe primitives compartilhados antes de criar CSS local
- [ ] usa tokens semânticos
- [ ] valida light/dark
- [ ] valida 320px/desktop
- [ ] keyboard + focus
- [ ] reduced motion
- [ ] empty/loading/error
- [ ] conteúdo longo
- [ ] não expõe status editorial no público sem necessidade
- [ ] não duplica componente existente
