# Component Spec — TEMPLATE

## Nome

## Problema semântico

## Quando usar / quando não usar

## Anatomy

## Variants

## Sizes

## States
- default
- hover
- focus-visible
- active/selected
- disabled
- loading
- error (se aplicável)

## Tokens usados

## Keyboard / ARIA

## Light/Dark

## Mobile

## Conteúdo extremo

## Testes obrigatórios

## Critério de remoção de implementação anterior
