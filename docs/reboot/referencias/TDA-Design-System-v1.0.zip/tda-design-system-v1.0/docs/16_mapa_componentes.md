# 16 — Mapa de componentes

## Canônicos no snapshot

| Primitive | Arquivo | Status |
|---|---|---|
| Action/Button/ActionLink | `components/ui/action.tsx` | canônico |
| Surface | `components/ui/surface.tsx` | canônico |
| Eyebrow/DisplayTitle/SectionTitle/BodyCopy/MetaText | `components/ui/typography.tsx` | canônico |
| StatusPill | `components/ui/status.tsx` | canônico |
| Theme tokens | `app/globals.css` | canônico |

## Próximos primitives recomendados

- `Field`, `Label`, `Input`, `Textarea`, `Select`;
- `Alert`/`InlineMessage`;
- `Dialog`/`Popover` com foco controlado;
- `Skeleton`;
- `EmptyState`;
- `IconButton`;
- `Tabs` se o Edit realmente demandar.

Esses itens são roadmap do Design System; **não são componentes existentes por este pacote sozinho**.
