# 13 — Implementação em Next/Tailwind

## Fonte de verdade

Tokens CSS vivem em `apps/web/app/globals.css` e são mapeados para Tailwind via `@theme inline`.

Exemplos de mapeamento:

```css
--color-canvas: var(--ds-canvas);
--color-surface: var(--ds-surface);
--color-foreground: var(--ds-foreground);
--color-accent: var(--ds-accent);
--color-action-primary: var(--ds-action-primary-bg);
--font-display: var(--ds-font-display);
--radius-lg: var(--ds-radius-lg);
```

## Uso em componente

Preferir classes semânticas:

```tsx
<section className="rounded-lg border border-border bg-surface text-foreground" />
```

Evitar:

```tsx
<section className="bg-[#151a20] text-[#eee8dc]" />
```

## Componentes compartilhados

- `components/ui/action.tsx`
- `components/ui/surface.tsx`
- `components/ui/typography.tsx`
- `components/ui/status.tsx`

## Regra de extensão

Se uma nova tela precisar de comportamento repetível, criar primitive/componente compartilhado antes da terceira repetição — ou antes, se a semântica/ acessibilidade justificar.
