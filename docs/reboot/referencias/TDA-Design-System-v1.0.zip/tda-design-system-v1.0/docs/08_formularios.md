# 08 — Formulários

## Estado

**NÃO existe ainda um primitive de formulário canônico auditado no snapshot.** Este capítulo é especificação para a modernização do Edit e futuras telas.

## Regras obrigatórias

- label persistente; placeholder não substitui label;
- erro associado ao campo e legível por leitor de tela;
- foco visível;
- altura de controle confortável (alvo de 44px para fluxo principal);
- `foreground` para valor, `foreground-muted` para ajuda;
- background de `surface`/`canvas-subtle`;
- estado inválido usa `danger` + texto, não só borda vermelha;
- não bloquear colar senha/token onde isso for tecnicamente apropriado;
- `autocomplete` correto em auth.

## Borda de controle

A borda visual padrão atual não chega a 3:1 contra surface. Para um input que dependa da borda para ser identificado, adotar um token específico de controle com contraste ≥3:1. Existe uma proposta em `tokens/proposed-extensions.css`; ela não é canônica até ser implementada e testada.

## Estrutura recomendada

`Field` → `Label` → `Control` → `Help/Error`. Agrupar campos relacionados com `fieldset`/`legend` quando houver semântica de conjunto.
