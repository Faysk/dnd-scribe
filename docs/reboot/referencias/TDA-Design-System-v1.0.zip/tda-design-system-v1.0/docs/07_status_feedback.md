# 07 — Status e feedback

## StatusPill canônico

Tons: `accent`, `success`, `danger`, `neutral`.

A pill atual sempre combina:
- fundo `canvas-subtle`;
- border `border-subtle`;
- texto `foreground-soft`;
- dot de cor do estado.

Isso é importante: **a cor não é o único significado**, porque existe texto visível.

## Onde usar

Na área pública, status editorial deve ser exceção. No Edit, pills são adequadas para estado de revisão, sincronização, processamento e permissão — desde que o texto seja explícito.

## Estados não definidos

O sistema ainda não possui token canônico separado para `warning` e `info`. Não inventar laranja/azul inline. Quando a necessidade real aparecer, criar papel semântico light/dark e validar contraste antes de adicionar.

## Feedback de ação

- sucesso: mensagem curta + ação seguinte quando houver;
- erro: explicar o que falhou e como recuperar;
- loading: manter contexto e evitar layout shift;
- empty state: explicar o que falta, sem fingir erro.
