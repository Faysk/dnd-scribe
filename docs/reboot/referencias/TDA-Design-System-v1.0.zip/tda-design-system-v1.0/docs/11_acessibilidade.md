# 11 — Acessibilidade

## Piso de contraste

- texto normal: **4.5:1**;
- texto grande: **3:1**;
- componentes/gráficos essenciais: **3:1** contra cores adjacentes quando a borda/forma for necessária para identificação.

## Foco

Canônico: outline 2px `accent-strong`, offset 3px em button, anchor, input, select e textarea. Não remover sem substituto mais forte.

## Teclado

- toda ação precisa ser alcançável;
- ordem de foco acompanha ordem visual/lógica;
- menus/popup fecham com Escape;
- não criar `div onClick` onde elemento semântico resolve.

## Touch

Meta: 44px para ação principal. Alvos menores precisam de contexto e espaçamento que evitem toque acidental.

## Leitores de tela

- headings em ordem;
- imagens informativas com alt útil; decorativas com alt vazio;
- ícones sozinhos precisam de accessible name;
- status dinâmico relevante deve usar live region quando apropriado.

## Movimento

Sempre testar `prefers-reduced-motion: reduce`.

## Contraste atual

`tokens/contrast-report.csv` registra os principais pares. O border padrão é fraco por design e não pode ser o único delimitador de controle essencial.
