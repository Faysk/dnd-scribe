# 01 — Princípios

## P1. História antes do sistema
A UI não deve parecer um painel administrativo quando o usuário está lendo memória, lore ou sessão. O sistema existe para sustentar a narrativa.

## P2. Semântica antes de hexadecimal
Use `foreground-muted`, não “cinza 500”. Use `action-primary`, não “amarelo”. O mesmo papel pode mudar de luminância entre temas.

## P3. Acento raro
O dourado é reservado para marca, navegação ativa, arco/metadado importante, foco e ação primária. Se tudo é dourado, nada é prioridade.

## P4. Claro e escuro têm a mesma hierarquia
O tema pode alterar fundo, contraste, sombra e intensidade; não deve alterar ordem de leitura ou fazer uma ação secundária virar dominante.

## P5. Legibilidade vence decoração
Nunca sacrificar contraste, tamanho de alvo, foco visível ou leitura longa por efeito visual.

## P6. Uma implementação compartilhada
Botão, card ou pill que reaparece deve ser componente compartilhado. Variantes locais só são justificáveis quando a semântica é realmente diferente.

## P7. Movimento é feedback
Animação deve explicar mudança de estado, hierarquia ou ação. Nada de glow contínuo ou movimento ornamental competindo com texto.

## P8. Mobile não é versão reduzida
No mobile, composição deve reordenar naturalmente: empilhar colunas, preservar alvos de toque e manter leitura confortável. Não apenas “espremer” desktop.
