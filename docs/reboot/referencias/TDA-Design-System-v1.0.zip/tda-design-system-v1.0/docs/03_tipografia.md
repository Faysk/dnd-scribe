# 03 — Tipografia

## Famílias canônicas

- `font-display`: Georgia, Times New Roman, serif;
- `font-body`: Georgia, Times New Roman, serif;
- `font-ui`: Inter, ui-sans-serif, system UI.

O sistema já funciona sem arquivo de fonte proprietário: Georgia entrega caráter editorial; a stack UI mantém controles eficientes e legíveis.

## Primitivos atuais

| Componente | Uso | Especificação atual |
|---|---|---|
| `Eyebrow` | metadado/chapéu | UI, 11px, bold, uppercase, tracking 0.18em, accent |
| `DisplayTitle` | título de página/hero | display, clamp 44–84px, line-height .96, tracking -0.045em |
| `SectionTitle` | título de seção | display, clamp 28–44px, line-height 1.02, tracking -0.03em |
| `BodyCopy` | narrativa/resumo | body, clamp 17–20px, line-height 1.7, foreground-soft |
| `MetaText` | data/auxiliar | UI, 12px, line-height 20px, muted |

## Regras

- fonte display nunca em botão, campo, menu ou controle;
- texto longo deve privilegiar `font-body` e linha confortável;
- caixa alta apenas para metadado curto;
- evitar centralizar parágrafos longos;
- títulos narrativos podem ser largos, mas não devem esmagar arte ou CTA.

## Escala operacional recomendada

Quando não houver primitive específica, partir de 12 / 14 / 16 / 18 / 20 / 24 / 28 / 36 / 44 / 56 / 72px, sempre verificando contexto e responsividade. **Esta escala é recomendação documental; os primitives acima são a implementação canônica atual.**
