# 00 — Visão geral

## Objetivo

O Design System do TDA existe para impedir divergência visual entre Home, Sessões, autenticação, Edit e futuras áreas do produto. A identidade deve sobreviver ao crescimento do site sem virar uma coleção de telas desenhadas isoladamente.

## Personalidade visual

- editorial e narrativa;
- limpa, madura e calma;
- D&D sem clichê de interface medieval;
- contraste alto e leitura confortável;
- dourado como sinal raro de importância, não decoração contínua;
- arte das sessões tem espaço para respirar;
- tema claro e escuro são duas luminâncias da mesma identidade.

## Regra de produto

**Visitante vê história; editor vê estado editorial.**

Na área pública, título, arco, data, resumo, arte e continuidade narrativa têm prioridade. Estados como “publicado”, “resumo completo”, “ilustrado”, “em preparação” e métricas de cobertura pertencem ao Edit, salvo quando alterarem uma ação disponível ao visitante.

## Arquitetura do sistema visual

1. **Tokens semânticos** definem papel, não pigmento.
2. **Primitivos de UI** (`Action`, `Surface`, tipografia, status) consomem tokens.
3. **Padrões de composição** definem cards, seções, navegação e forms.
4. **Telas** combinam padrões sem inventar variantes locais.
5. **Auditoria** valida light/dark, foco, contraste, responsividade e coerência.
