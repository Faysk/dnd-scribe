# 02 — Cores e temas

## Status

Os valores deste capítulo são **CANÔNICOS** e correspondem a `apps/web/app/globals.css` no snapshot.

## Tema escuro

| Papel | Token | Valor |
|---|---|---|
| canvas | `--ds-canvas` | `#0a0c0f` |
| canvas-subtle | `--ds-canvas-subtle` | `#101419` |
| surface | `--ds-surface` | `#151a20` |
| surface-hover | `--ds-surface-hover` | `#1a2027` |
| surface-elevated | `--ds-surface-elevated` | `#11151a` |
| border | `--ds-border` | `#2a3038` |
| border-subtle | `--ds-border-subtle` | `rgba(255, 255, 255, 0.07)` |
| foreground | `--ds-foreground` | `#eee8dc` |
| foreground-soft | `--ds-foreground-soft` | `#c8c2b7` |
| foreground-muted | `--ds-foreground-muted` | `#9aa1aa` |
| accent | `--ds-accent` | `#d7aa61` |
| accent-strong | `--ds-accent-strong` | `#f2c879` |
| accent-muted | `--ds-accent-muted` | `rgba(215, 170, 97, 0.13)` |
| accent-contrast | `--ds-accent-contrast` | `#17120b` |
| action-primary-bg | `--ds-action-primary-bg` | `#e7b95f` |
| action-primary-hover | `--ds-action-primary-hover` | `#f2c879` |
| action-primary-foreground | `--ds-action-primary-foreground` | `#15100a` |
| action-primary-border | `--ds-action-primary-border` | `#e7b95f` |
| danger | `--ds-danger` | `#e59383` |
| success | `--ds-success` | `#8fc49b` |
| shadow | `--ds-shadow` | `0 24px 80px rgba(0, 0, 0, 0.28)` |
| ambient-accent | `--ds-ambient-accent` | `rgba(215, 170, 97, 0.09)` |
| ambient-cool | `--ds-ambient-cool` | `rgba(75, 91, 109, 0.08)` |

## Tema claro

| Papel | Token | Valor |
|---|---|---|
| canvas | `--ds-canvas` | `#f3efe7` |
| canvas-subtle | `--ds-canvas-subtle` | `#fffdf8` |
| surface | `--ds-surface` | `#e9e3d8` |
| surface-hover | `--ds-surface-hover` | `#ffffff` |
| surface-elevated | `--ds-surface-elevated` | `#fffdf8` |
| border | `--ds-border` | `#c8c0b3` |
| border-subtle | `--ds-border-subtle` | `rgba(25, 25, 23, 0.12)` |
| foreground | `--ds-foreground` | `#191917` |
| foreground-soft | `--ds-foreground-soft` | `#4f4b44` |
| foreground-muted | `--ds-foreground-muted` | `#625d55` |
| accent | `--ds-accent` | `#805817` |
| accent-strong | `--ds-accent-strong` | `#9a6a1d` |
| accent-muted | `--ds-accent-muted` | `rgba(128, 88, 23, 0.11)` |
| accent-contrast | `--ds-accent-contrast` | `#fffdf8` |
| action-primary-bg | `--ds-action-primary-bg` | `#805817` |
| action-primary-hover | `--ds-action-primary-hover` | `#6b4913` |
| action-primary-foreground | `--ds-action-primary-foreground` | `#fffdf8` |
| action-primary-border | `--ds-action-primary-border` | `#805817` |
| danger | `--ds-danger` | `#9a3025` |
| success | `--ds-success` | `#326c42` |
| shadow | `--ds-shadow` | `0 24px 70px rgba(48, 39, 28, 0.14)` |
| ambient-accent | `--ds-ambient-accent` | `rgba(128, 88, 23, 0.08)` |
| ambient-cool | `--ds-ambient-cool` | `rgba(92, 78, 58, 0.05)` |

## Uso

### Canvas
`canvas` é o fundo global. `canvas-subtle` cria regiões discretamente separadas sem parecer card elevado.

### Surface
`surface` é a superfície padrão; `surface-elevated` é reservada a elementos que realmente precisam subir na hierarquia; `surface-hover` é feedback transitório.

### Foreground
- `foreground`: títulos, labels e conteúdo crítico;
- `foreground-soft`: corpo de texto e conteúdo narrativo;
- `foreground-muted`: metadados e informação auxiliar.

### Accent
- `accent`: metadado forte, eyebrow, navegação ativa;
- `accent-strong`: foco e destaque pontual;
- `accent-muted`: fundos de hover/seleção sem saturação alta.

### Action primary
A ação primária usa tokens próprios. Não derivar botão primário diretamente de `accent`, porque contraste e hover são contratos diferentes.

## Contraste

Consulte `tokens/contrast-report.csv`. Os pares de texto principais ultrapassam WCAG AA com folga. O border padrão **não atinge 3:1 contra o canvas/surface** e, portanto, deve ser tratado como separador/decorativo — nunca como único sinal de fronteira de um controle essencial. Para controles que dependam da borda, veja `tokens/proposed-extensions.css`.

## Não fazer

- hex inline em componente;
- texto creme/branco sobre amarelo claro;
- inventar um segundo dourado para um componente isolado;
- usar `danger` como decoração;
- comunicar estado só pela cor.
