# 10 — Movimento e interação

## Base canônica

Ações usam transições de `background-color`, `border-color`, `color` e `transform` em 150ms.

## `prefers-reduced-motion`

`globals.css` reduz transições e animações não essenciais para 0.01ms e remove smooth scrolling quando o usuário solicita menos movimento. Essa regra é obrigatória em qualquer novo componente.

## Diretrizes

- hover pode deslocar ação 1px;
- popover pode usar fade/scale curto;
- evitar glow pulsante, parallax contínuo, floating infinito;
- não animar grandes áreas sem propósito;
- loading indeterminado deve respeitar reduced motion;
- transição de tema não deve provocar flash agressivo.
