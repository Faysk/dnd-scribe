# 06 — Superfícies e cards

## `Surface` canônico

Tons atuais:

- `default`: `border-border bg-surface`;
- `elevated`: `border-border bg-surface-elevated shadow-elevated`;
- `subtle`: `border-border-subtle bg-canvas-subtle`.

Todos usam `rounded-lg` e `text-foreground`.

## Quando usar

### Default
Cards comuns, blocos de configuração, agrupamentos que precisam de limite.

### Elevated
Popover, painel focal, hero editorial quando profundidade ajuda a hierarquia. Evitar empilhar sombra sobre sombra.

### Subtle
Mensagens vazias, agrupamentos de apoio, seções que precisam separar sem parecer “cartão premium”.

## Card de última memória

Ordem recomendada:

1. `Última memória`;
2. arco como metadado editorial;
3. título;
4. resumo;
5. data;
6. CTA;
7. arte.

Texto e imagem devem ter peso semelhante. Arte usa crop intencional (`object-cover`, central por padrão), nunca deformação.

## Card de arquivo

Ordem: arco → data → título → resumo curto → imagem. Não exibir status editorial.

## Radius

Canônico: 8 / 12 / 18 / 24px (`sm`/`md`/`lg`/`xl`). O primitive `Surface` usa `lg` (18px via token Tailwind).
