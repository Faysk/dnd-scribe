# 14 — Governança do Design System

## Mudança de token

1. definir o problema semântico;
2. verificar se token existente resolve;
3. criar valores light/dark;
4. medir contraste;
5. atualizar catálogo visual;
6. migrar componentes;
7. rodar unit/E2E/a11y;
8. remover token antigo somente após não haver consumidores.

## Mudança de componente

- preservar API quando possível;
- documentar breaking change;
- evitar duas versões permanentes (`ButtonV1`, `ButtonV2`);
- se houver janela de migração, registrar prazo/critério de remoção.

## Definition of Done visual

Uma tela não está pronta só porque “parece boa” no desktop dark. Precisa passar: light, dark, 320px, desktop, teclado, reduced motion, conteúdo longo, estado vazio/erro/loading, contraste e foco.

## Relação com Brand Pack

Logo, ícone e lockups não devem ser redesenhados pelo Design System. O DS define **como a interface recebe a marca**, não a geometria da marca.
