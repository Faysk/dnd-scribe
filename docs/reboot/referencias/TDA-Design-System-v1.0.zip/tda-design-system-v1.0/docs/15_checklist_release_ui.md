# 15 — Checklist de release de UI

Use antes de mergear uma tela/componente novo.

## Semântica
- [ ] usa tokens semânticos em vez de hex inline;
- [ ] não cria variante visual duplicada sem necessidade;
- [ ] ação principal está claramente definida;
- [ ] público não recebe estado editorial interno sem motivo.

## Tema
- [ ] dark revisado;
- [ ] light revisado;
- [ ] system preference sem preferência explícita;
- [ ] contraste medido nos pares novos.

## Responsividade
- [ ] 320px;
- [ ] mobile comum;
- [ ] tablet;
- [ ] desktop amplo;
- [ ] texto longo/arc longo não quebra composição.

## Interação
- [ ] hover não é único feedback;
- [ ] focus-visible funciona;
- [ ] disabled/loading preservam contexto;
- [ ] Escape/click-outside em overlays.

## Acessibilidade
- [ ] heading hierarchy;
- [ ] accessible names;
- [ ] keyboard-only;
- [ ] reduced motion;
- [ ] alt text;
- [ ] erro de formulário associado ao campo.

## Conteúdo
- [ ] estados empty/error/loading;
- [ ] labels e microcopy específicos;
- [ ] arte sem deformação;
- [ ] metadados não competem com título.
