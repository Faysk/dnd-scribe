# 09 — Navegação

## Princípios

- logo/mark leva à Home; não duplicar “Início” sem necessidade;
- estado ativo pode usar accent, mas deve também ter forma/posição/texto coerente;
- navegação principal curta;
- ações de conta ficam separadas de navegação de conteúdo;
- menu móvel deve preservar foco, Escape, click-outside e ARIA.

## Header

A navegação pública deve priorizar descoberta de conteúdo, hoje especialmente `Sessões`. O menu de usuário concentra identidade, função e ações administrativas.

## Breadcrumbs

Usar quando a profundidade real do conteúdo passar de dois níveis e o usuário puder se beneficiar de orientação. Não adicionar breadcrumbs decorativos em páginas simples.

## Tabs

Tabs representam visões do mesmo contexto, não navegação global. Devem manter seleção sem depender apenas da cor.
