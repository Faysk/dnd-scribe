# 05 — Ações, botões e links

## Implementação canônica

Usar `Button`, `ActionLink` ou `actionStyles` de `apps/web/components/ui/action.tsx`.

## Variantes

### Primary
A única ação dominante do bloco. Fundo `action-primary`, texto `action-primary-foreground`, border correspondente. Hover muda para `action-primary-hover` e pode subir 1px.

Exemplos: **Ler esta memória**, **Salvar alterações**, **Publicar** quando realmente for a ação principal.

### Secondary
Ação importante sem dominar. `surface` + `border` + `foreground`; hover usa `surface-hover`.

### Tertiary
Navegação auxiliar e baixa prioridade. Sem borda permanente; hover usa `accent-muted`.

## Tamanhos canônicos

| Size | Altura mínima | Padding X | Texto |
|---|---:|---:|---:|
| `sm` | 36px | 12px | 12px |
| `md` | 44px | 16px | 14px |

## Estados

- default;
- hover: mudança de fundo/borda + transform opcional de 1px;
- focus-visible: outline 2px `accent-strong`, offset 3px;
- disabled: sem pointer events, opacity 50%;
- loading: **recomendado** preservar largura e incluir texto/indicador acessível, não trocar por spinner sem label.

## Regras de prioridade

- preferir uma primary por seção/bloco;
- duas ações lado a lado: primary + secondary ou secondary + tertiary;
- delete/destructive nunca deve usar aparência da primary dourada;
- link dentro de parágrafo deve parecer link por mais de um sinal quando necessário (underline/estado), não depender só de cor.
