# 12 — Conteúdo e hierarquia editorial

## Regra principal

**Visitante vê história; editor vê estado editorial.**

## Público

Priorizar:
- título da sessão;
- arco;
- data;
- resumo;
- arte;
- continuidade (“última memória”, “memórias recentes”).

Evitar:
- “publicado”;
- “resumo completo”;
- “ilustrado”;
- “em preparação”;
- contadores internos e cobertura editorial.

## Edit

O Edit pode mostrar status, permissões, revisão, pipeline e diagnóstico — mas deve separar isso claramente do conteúdo narrativo.

## Microcopy

Preferir linguagem humana e contextual. Erros devem explicar recuperação; ações devem usar verbo específico (`Salvar`, `Publicar`, `Baixar transcrição`) em vez de rótulos vagos (`OK`, `Continuar`) quando a ação puder ser ambígua.
