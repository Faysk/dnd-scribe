# 04 — Espaçamento, layout e responsividade

## Estado

O projeto atual usa principalmente utilitários Tailwind; ainda não existe uma escala `--ds-space-*` canônica no CSS. Este capítulo padroniza uso sem fingir que tokens inexistentes já foram implementados.

## Escala operacional recomendada

`4, 8, 12, 16, 20, 24, 32, 40, 48, 64, 80, 96 px`.

Usar 4/8/12 para microespaçamento; 16/20/24 para interior de componentes; 32/40/48 entre blocos; 64+ para seções editoriais.

## Containers

- conteúdo principal: largura fluida com margens laterais seguras;
- Home atual trabalha próxima de `1180px`;
- card editorial de destaque: aproximadamente `1080px` como teto recomendado;
- texto corrido não deve ocupar toda a largura de um desktop grande.

## Grid

- desktop: duas colunas quando texto e arte têm peso equivalente;
- tablet: reduzir gap antes de reduzir tipografia agressivamente;
- mobile: empilhar; arte vira bloco próprio, sem largura residual estreita.

## Breakpoints

Seguir breakpoints do Tailwind do projeto em vez de criar media queries locais arbitrárias. A semântica deve ser “layout muda porque composição precisa”, não “porque este device tem nome X”.

## Touch

A ação padrão `md` tem min-height de 44px. Controles compactos de 36px (`sm`) devem ser usados em contexto onde densidade é necessária e não como alvo primário isolado em mobile.
