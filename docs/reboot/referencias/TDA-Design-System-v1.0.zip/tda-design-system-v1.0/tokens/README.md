# Tokens

- `tda-design-tokens.css`: snapshot canônico de papéis light/dark.
- `tda-design-tokens.json`: formato estruturado para tooling.
- `contrast-report.csv`: auditoria numérica dos principais pares.
- `proposed-extensions.css`: propostas explicitamente **não canônicas** para lacunas.

A aplicação continua tendo `apps/web/app/globals.css` como fonte operacional. Este diretório serve como distribuição/documentação do sistema.
