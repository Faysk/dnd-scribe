# Fontes do snapshot

Este pacote foi montado a partir da `main` do repositório `Faysk/dnd-scribe`, commit `68e974c0eb240e1658772f8ae64da36530f9452e`.

Arquivos-base:

- `docs/08_design_system_visual.md`
- `apps/web/app/globals.css`
- `apps/web/components/ui/action.tsx`
- `apps/web/components/ui/surface.tsx`
- `apps/web/components/ui/typography.tsx`
- `apps/web/components/ui/status.tsx`

Contexto de identidade usado apenas para nomenclatura: `TDA — Tem Dado Aqui` e assinatura `Rolamos dados. Guardamos os dados.` do Brand Pack aprovado.

## Nota importante

Os capítulos sobre **formulários, navegação, spacing operacional e tokens de controle forte** ampliam a documentação para cobrir lacunas do sistema. Quando algo ainda não existe na `main`, ele é explicitamente marcado como **RECOMENDADO / NÃO CANÔNICO**.
