# TDA — Design System

Pacote autônomo de documentação do **Design System do TDA — Tem Dado Aqui**.

**Versão do pacote:** 1.0.0  
**Data:** 2026-09-06  
**Snapshot do projeto:** `Faysk/dnd-scribe@68e974c0eb240e1658772f8ae64da36530f9452e`

## Escopo

Este ZIP é **somente Design System**: cores, temas, tipografia, hierarquia, ações, superfícies, cards, estados, formulários, navegação, movimento, acessibilidade, padrões de conteúdo, implementação e governança.

Ele **não substitui o Brand Pack** de logo/ícone/favicons. Os masters da marca continuam em um pacote separado. Aqui a marca aparece apenas como contexto de uso da interface.

## Fonte de verdade

A hierarquia de autoridade é:

1. `reference/current/globals.css` — tokens realmente implementados na `main` do snapshot;
2. `reference/current/*.tsx` — componentes React compartilhados já existentes;
3. `docs/` — especificação operacional deste pacote;
4. `tokens/proposed-extensions.css` — **recomendações ainda não canônicas** para lacunas identificadas.

Nunca trate `proposed-extensions.css` como já implementado no produto sem antes migrar o código e passar CI/E2E/auditoria visual.

## Princípio central

> **Visitante vê história; editor vê estado editorial.**

O TDA é um arquivo narrativo, não um dashboard administrativo disfarçado.

## Comece por aqui

- `docs/00_visao_geral.md`
- `docs/02_cores_e_temas.md`
- `docs/05_acoes_botoes_links.md`
- `docs/11_acessibilidade.md`
- `docs/15_checklist_release_ui.md`
- `preview/index.html` — catálogo visual offline com troca de tema
- `tokens/tda-design-tokens.css` — tokens semânticos canônicos
- `tokens/tda-design-tokens.json` — mesma base em formato estruturado

## Regra de governança

Não introduzir hexadecimal direto em componente de interface quando já houver papel semântico equivalente. Se uma nova necessidade visual não tiver token, primeiro especificar o papel semântico; depois criar o token para **claro e escuro**; só então consumir no componente.
