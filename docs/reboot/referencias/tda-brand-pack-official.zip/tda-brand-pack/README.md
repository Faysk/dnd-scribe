# TDA — Tem Dado Aqui — Brand Pack

Pack oficial de identidade visual para o site da campanha.

## Estrutura

- `source/` — arquivos master aprovados.
- `logos/` — símbolo principal e lockups com o nome TDA.
- `icons/` — ícones do pato, favicons, Apple Touch, Android/PWA e Safari.
- `social/` — cards para Open Graph e Twitter/X.
- `pwa/` — manifest e browserconfig.
- `docs/` — guia de marca, snippet de integração, tokens e textos sugeridos.
- `preview/` — folhas visuais do pack.

## Instalação sugerida

Copie a pasta inteira para:

`public/brand/`

Depois use `docs/INTEGRATION_SNIPPET.html` como base.
