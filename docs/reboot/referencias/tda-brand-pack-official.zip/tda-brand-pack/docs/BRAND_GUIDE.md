# TDA — Tem Dado Aqui — Brand Guide

## Marca oficial

A identidade visual é formada por:

- **Símbolo principal:** d20 geométrico com o pato ao centro.
- **Ícone:** silhueta isolada do pato.
- **Nome:** **TDA**
- **Expansão do nome:** **Tem Dado Aqui**
- **Assinatura recomendada:** **Rolamos dados. Guardamos os dados.**

## O que usar em cada lugar

- **Navbar / header:** `tda-horizontal-*`
- **Hero / páginas institucionais:** `tda-stacked-*` ou `tda-horizontal-*`
- **Favicon / app / botões compactos:** ícone do pato isolado
- **Social preview:** `social/og-image.png`

## Escolha por fundo

| Fundo | Arquivo |
|---|---|
| Claro | versões `-black` |
| Escuro | versões `-white` |
| Imagem / fundo complexo | usar a versão com maior contraste |

## Regras

1. Não alterar proporções.
2. Não redesenhar o pato.
3. Não misturar versões branca e preta no mesmo lockup sem necessidade.
4. Não aplicar sombra, glow, bevel ou gradientes no master.
5. Em tamanhos pequenos, preferir o ícone do pato ao logo completo.
6. Ao escrever o nome, usar preferencialmente `TDA` com `Tem Dado Aqui` como complemento quando houver espaço.

## Microcopy sugerida

- **Nome curto:** `TDA`
- **Nome completo:** `TDA — Tem Dado Aqui`
- **Tagline:** `Rolamos dados. Guardamos os dados.`
- **Descrição curta:** `Sessões, personagens, histórias e memórias da nossa campanha.`

## Estrutura sugerida no projeto

Coloque a pasta inteira como `public/brand/`.
