# Copy sugerido

## Nome da marca
- **Curto:** TDA
- **Completo:** TDA — Tem Dado Aqui

## Taglines candidatas
1. Rolamos dados. Guardamos os dados.
2. A sessão passa. Os dados ficam.
3. Onde a campanha continua viva.

## Descrição curta
Sessões, personagens, histórias e memórias da nossa campanha de D&D.

## Descrição média
TDA — Tem Dado Aqui é o arquivo vivo da nossa campanha: sessões, personagens, causos, imagens, músicas e todo o caos digno de ser lembrado.
